View my website

Skills: Dart, Java, HTML, CSS, Flutter, Firebase, REST APIs, SQLite, Git/GitHub, AWS, Cloud Security

Certifications: Java (NPTEL), IoT (NPTEL), Computer Concepts

Experience:

Mobile App Dev Intern – Softpro India (Mar–Apr 2025)
Cloud Security Analyst Intern – AMSKILLS (May 2025–Present)
Operation Executive – AMSKILLS (May 2025–Present)

Projects:
Library Management System – Digital system for books & records
Online Kachehari – Platform for online legal/helpdesk support
